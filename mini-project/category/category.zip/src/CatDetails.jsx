function CatDetails(){
    return(
        <>
        <hi>Ctaegory details</hi>
        </>
    )
}
export {CatDetails}