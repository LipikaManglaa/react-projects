import logo from './logo.svg';
import './App.css';
import { useEffect, useState } from 'react';
import axios from  'axios';

import { Link } from 'react-router-dom';

function App() {
  let[product,setproduct]=useState([]);
  let[category,setcategory]=useState([]);
  let[activeCat,setActiveCat]=useState("")
  let [show, setShow] = useState(false);
  let [productModalDeatils,setproductModalDeatils]=useState([])


  
  let apiUrl;
  //all product here
  let getProduct=(catName="")=>{
    if(catName===""){
    apiUrl= `https://dummyjson.com/products`;
    
  }
  else{
    apiUrl=`https://dummyjson.com/products/category/${catName}`
    setActiveCat(catName)
  }
axios.get(apiUrl)
.then((res)=>{
  return res.data
})
.then((finalData)=>{
  setproduct(finalData.products)
  setproductModal(finalData.products)
})
  }
  //all category here
  let getCategory=()=>{
   let apiCatUrl= `https://dummyjson.com/products/categories`;
 
axios.get(apiCatUrl)
.then((res)=>{
  setcategory(res.data)
})

  }
  useEffect(()=>{
    getProduct();
    getCategory()
  },[])

   //modal

  //  let productModalDecsription=()=>{
  //   let apiUrlModal=`https://dummyjson.com/products`
  //   axios.get(apiUrlModal)
  //   .then((res)=>{
  //     return res.data
  //   })
  //   .then((finalData)=>{
      
  //   })
  // }
  // productModalDecsription()
    let productitems= product.map((item,i)=>{
       return(
        <>
        <Card productDetails={item} key={i}/>
        <CatDeatilsCart CatDeatilsList={item} key={i}/>
        </>
       )
      
    })
   
 


  
  return (
    <div className="App">




<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Modal title</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        ...
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>






    <div className=' container my-5'>
      <div className='row'>
       
        <div className='col-3'>
        <ul className="list-group">
        <h3 className='my-4'>All Categories</h3>
        {
          category.map((v,i)=>{
            return(
              <>
                <li className={`list-group-item ${(v===activeCat) ? 'active' :  ''}`}  key={i} onClick={()=>getProduct(v)} style={{cursor:'pointer'}}>{v}</li>
              </>
            )
          })
        }

 
</ul>
        </div>
        <div className='col-9'>
          <div className='row'>
            <h3 className='my-4'>All products</h3>
       {productitems}
          </div>
        </div>
      </div>
    </div>
    </div>
  );
}

export default App;

function Card({productDetails}){

  return(
    
    <div className='col-4'>
    <div class="card" >
      <div    className='w-100' style={{
        height:'250px',
         background:`url("${productDetails.thumbnail}")center`,
         backgroundSize:'cover'
         }}></div>
<div className="card-body">
<h5 className="card-title"  data-bs-toggle="modal" data-bs-target="#exampleModal"   onClick={()=> productModal(productDetails.id)}>{productDetails.title}</h5>

<p className="card-text">{productDetails.description}</p>

</div>
</div>
    </div>
  )
}

//modal

// productModal()

function productModal(id){
  console.log(id)

  let apiUrl1=`https://dummyjson.com/products/${id}`;
  axios.get(apiUrl1)
.then((res)=>{
  console.log(res)
  // setproductModalDeatils(res.data)
})
 
}




export {App}