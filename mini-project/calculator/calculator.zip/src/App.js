import logo from './logo.svg';
import './App.css';
import Caslculator from './component/Caslculator';

function App() {
  return (
    <div className="App">
      <Caslculator/>
        </div>
  );
}

export default App;
